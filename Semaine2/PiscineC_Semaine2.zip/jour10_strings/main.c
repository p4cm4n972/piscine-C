#include <stdio.h>
void ft_strrev(char *str);
int main(){char s[]="Piscine";ft_strrev(s);printf("%s\n",s);return 0;}