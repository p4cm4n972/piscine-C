#include <stdio.h>
int ft_binary_search(int *tab,int size,int target);
int main(){int t[]={1,3,5,7,9};printf("%d\n",ft_binary_search(t,5,7));return 0;}