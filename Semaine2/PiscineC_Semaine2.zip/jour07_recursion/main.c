#include <stdio.h>
int main(){printf("Factorial(5)=%d\n",ft_recursive_factorial(5));return 0;}