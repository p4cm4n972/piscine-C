#include <unistd.h>
int main(){ft_print_alphabet();return 0;}