#ifndef LIBFT_H
#define LIBFT_H
void ft_putchar(char c);
void ft_putstr(char *str);
int ft_strlen(char *str);
int ft_strcmp(char *s1,char *s2);
char *ft_strcpy(char *dest,char *src);
void ft_swap(int *a,int *b);
void ft_sort_int_tab(int *tab,int size);
#endif